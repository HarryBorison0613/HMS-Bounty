const homeView = (req, res) => {
    res.render('home', {
    });
}

module.exports = {
    homeView
}